const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const { getDatabase, ref, get, set, update, push } = require('./db/firebase-mock');
const { executeBlockchainTransaction } = require('./db/blockchain-service');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'app')));

// GET account details
app.get('/api/accounts/:accountNumber', async (req, res) => {
  const { accountNumber } = req.params;
  try {
    const db = getDatabase();
    const accountRef = ref(db, `accounts/${accountNumber}`);
    const snapshot = await get(accountRef);

    if (snapshot.exists()) {
      const data = snapshot.val();
      // Don't return password in normal fetch
      const { balancePassword, paymentPassword, ...publicData } = data;
      res.json({ success: true, account: publicData });
    } else {
      res.status(404).json({ success: false, error: 'Account not found' });
    }
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST check balance (requires password)
app.post('/api/balance', async (req, res) => {
  const { accountNumber, password } = req.body;

  if (!accountNumber || !password) {
    return res.status(400).json({ success: false, error: 'Missing account number or password' });
  }

  try {
    const db = getDatabase();
    const accountRef = ref(db, `accounts/${accountNumber}`);
    const snapshot = await get(accountRef);

    if (!snapshot.exists()) {
      return res.status(404).json({ success: false, error: 'Account not found' });
    }

    const account = snapshot.val();
    if (account.balancePassword !== password) {
      return res.status(401).json({ success: false, error: 'Invalid password' });
    }

    res.json({ success: true, balance: account.balance, currency: account.currency });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST payment execution
app.post('/api/pay', async (req, res) => {
  const { fromAccount, toAccount, amount, targetCurrency, rate, password } = req.body;

  // Basic validation
  if (!fromAccount || !toAccount || !amount || !targetCurrency || !password) {
    return res.status(400).json({ success: false, error: 'Missing required parameters' });
  }

  try {
    const db = getDatabase();
    
    // Get sender account
    const fromRef = ref(db, `accounts/${fromAccount}`);
    const fromSnap = await get(fromRef);

    if (!fromSnap.exists()) {
      return res.status(404).json({ success: false, error: 'Sender account not found' });
    }

    const sender = fromSnap.val();

    // Validate payment password
    if (sender.paymentPassword !== password) {
      return res.status(401).json({ success: false, error: 'Incorrect password' });
    }

    // Validate funds
    const numAmount = parseFloat(amount);
    if (sender.balance < numAmount) {
      return res.status(400).json({ success: false, error: 'Insufficient funds' });
    }

    // Determine target recipient (it could be an account number or simple phone pay alias number)
    let recipientName = "User (" + toAccount + ")";
    let isInternal = false;
    
    const toRef = ref(db, `accounts/${toAccount}`);
    const toSnap = await get(toRef);
    if (toSnap.exists()) {
      isInternal = true;
      recipientName = toSnap.val().owner;
    }

    // Conversion details
    const convRate = parseFloat(rate || 1.0);
    const convertedAmount = numAmount * convRate;

    // 1. EXECUTE BLOCKCHAIN TRANSACTION (Solidity Parser inside)
    let blockchainResult;
    try {
      blockchainResult = executeBlockchainTransaction(
        fromAccount,
        toAccount,
        numAmount,
        sender.currency,
        targetCurrency,
        convertedAmount,
        Math.round(convRate * 1000000)
      );
    } catch (bcError) {
      return res.status(500).json({ success: false, error: `Blockchain validation error: ${bcError.message}` });
    }

    // 2. UPDATE DATABASE (Firebase simulation)
    // Deduct sender balance
    const newSenderBalance = sender.balance - numAmount;
    await update(fromRef, { balance: newSenderBalance });

    // If recipient is internal, credit their account in their currency
    if (isInternal) {
      const recipient = toSnap.val();
      // Since recipient might have a different currency, convert the sender's sent amount to recipient's currency
      // But for simplicity, we credit the converted amount if their currency matches the targetCurrency
      let creditedAmount = convertedAmount;
      if (recipient.currency !== targetCurrency) {
        // Here we just credit the converted amount directly if they matched
        // If not, we assume targetCurrency is recipient's currency
      }
      const newRecipBalance = recipient.balance + creditedAmount;
      await update(toRef, { balance: newRecipBalance });
    }

    // Log transaction
    const newTx = {
      txHash: blockchainResult.transactionHash,
      blockNumber: blockchainResult.blockNumber,
      timestamp: blockchainResult.timestamp,
      fromAccount,
      toAccount,
      recipientName,
      amount: numAmount,
      fromCurrency: sender.currency,
      toCurrency: targetCurrency,
      convertedAmount,
      rate: convRate,
      status: 'SUCCESS'
    };

    const txsRef = ref(db, 'transactions');
    await push(txsRef, newTx);

    res.json({
      success: true,
      receipt: newTx,
      blockchain: blockchainResult
    });

  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET transaction history for a specific account
app.get('/api/transactions/:accountNumber', async (req, res) => {
  const { accountNumber } = req.params;
  try {
    const db = getDatabase();
    const txsRef = ref(db, 'transactions');
    const snapshot = await get(txsRef);

    const history = [];
    if (snapshot.exists()) {
      const txs = snapshot.val();
      // Txs might be an object/dict or an array
      const list = Array.isArray(txs) ? txs : Object.values(txs);
      list.forEach(tx => {
        if (tx.fromAccount === accountNumber || tx.toAccount === accountNumber) {
          history.push(tx);
        }
      });
    }

    // Sort by timestamp desc
    history.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    res.json({ success: true, history });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST register temporary/fixed-rate or general QR
app.post('/api/qr/create', async (req, res) => {
  const { type, accountNumber, amount, currency, expiresAt } = req.body;

  if (!accountNumber || !type) {
    return res.status(400).json({ success: false, error: 'Missing account number or QR type' });
  }

  try {
    const db = getDatabase();
    const qrId = 'qr_' + Math.random().toString(36).substr(2, 9);
    
    const qrConfig = {
      qrId,
      type, // 'GENERAL' or 'FIXED'
      accountNumber,
      amount: type === 'FIXED' ? parseFloat(amount) : null,
      currency: currency || 'INR',
      expiresAt: expiresAt || null,
      createdAt: new Date().toISOString()
    };

    const qrRef = ref(db, `qrCodes/${qrId}`);
    await set(qrRef, qrConfig);

    res.json({ success: true, qr: qrConfig });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET QR details
app.get('/api/qr/:qrId', async (req, res) => {
  const { qrId } = req.params;
  try {
    const db = getDatabase();
    const qrRef = ref(db, `qrCodes/${qrId}`);
    const snapshot = await get(qrRef);

    if (snapshot.exists()) {
      const qr = snapshot.val();
      
      // Check expiry for temporary QR
      if (qr.expiresAt && new Date() > new Date(qr.expiresAt)) {
        return res.status(410).json({ success: false, error: 'QR Code has expired' });
      }
      
      res.json({ success: true, qr });
    } else {
      res.status(404).json({ success: false, error: 'QR Code not found' });
    }
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Start listening
app.listen(PORT, () => {
  console.log(`[GoldPay Node Service] SAP CAP model server listening on http://localhost:${PORT}`);
});
