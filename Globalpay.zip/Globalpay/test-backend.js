const assert = require('assert');
const { verifyContractMethods, executeBlockchainTransaction } = require('./db/blockchain-service');
const { getDatabase, ref, get, set, update, push } = require('./db/firebase-mock');

async function runTests() {
  console.log("=========================================");
  console.log("    GOLDPAY BACKEND TEST VALIDATION      ");
  console.log("=========================================");

  let failed = false;

  // TEST 1: Solidity Contract Parser
  try {
    console.log("[Test 1/3] Parsing PaymentContract.sol...");
    const verification = verifyContractMethods();
    assert.strictEqual(verification.success, true, "Solidity parsing should succeed");
    assert.strictEqual(verification.verifiedMethod, "processCrossBorderPayment", "Method name processCrossBorderPayment should be verified");
    console.log(`✅ Success: Solidity smart contract parsed. Length: ${verification.contractLength} chars.`);
  } catch (err) {
    console.error("❌ Test 1 Failed:", err.message);
    failed = true;
  }

  // TEST 2: Blockchain Transaction Simulator
  try {
    console.log("[Test 2/3] Simulating cross-border payment mining block...");
    const tx = executeBlockchainTransaction(
      "987654321098",
      "112233445566",
      150.00,
      "INR",
      "USD",
      1.80,
      0.012
    );
    assert.ok(tx.transactionHash.startsWith("0x7a4d"), "Tx hash must start with 0x7a4d");
    assert.ok(tx.blockNumber > 0, "Block number must be defined");
    assert.ok(tx.contractVerified, "Contract must be verified");
    console.log(`✅ Success: Mined transaction block. Hash: ${tx.transactionHash}, Block: ${tx.blockNumber}`);
  } catch (err) {
    console.error("❌ Test 2 Failed:", err.message);
    failed = true;
  }

  // TEST 3: Mock Firebase CRUD API
  try {
    console.log("[Test 3/3] Verifying mock Firebase database CRUD functions...");
    const db = getDatabase();
    const testRef = ref(db, "accounts/987654321098");
    const snap = await get(testRef);
    
    assert.ok(snap.exists(), "Initial account 987654321098 should exist in schema.json");
    const account = snap.val();
    assert.strictEqual(account.owner, "Kodam Shishir Bhagath", "Account owner should be Kodam Shishir Bhagath");

    // Test transaction push
    const txsRef = ref(db, "transactions");
    const pushResult = await push(txsRef, {
      testTx: true,
      timestamp: new Date().toISOString()
    });
    assert.ok(pushResult.key.startsWith("key_"), "Pushed key should be generated");
    
    // Check if written
    const txsSnap = await get(txsRef);
    assert.ok(txsSnap.exists(), "Transactions index should exist");
    
    console.log(`✅ Success: Firebase CRUD simulation matches real API specs.`);
  } catch (err) {
    console.error("❌ Test 3 Failed:", err.message);
    failed = true;
  }

  console.log("-----------------------------------------");
  if (failed) {
    console.log("❌ Result: Some tests failed. Please review console logs.");
    process.exit(1);
  } else {
    console.log("🎉 Result: All backend tests passed successfully!");
    process.exit(0);
  }
}

runTests();
