const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'schema.json');

// Helper to read database
function readDB() {
  try {
    if (!fs.existsSync(DB_PATH)) {
      return { accounts: {}, transactions: [], qrCodes: {} };
    }
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error("Error reading mock database:", err);
    return { accounts: {}, transactions: [], qrCodes: {} };
  }
}

// Helper to write database
function writeDB(data) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error("Error writing mock database:", err);
  }
}

// Simulated Firebase DB Reference
class MockRef {
  constructor(pathStr) {
    // Normalize path (remove leading/trailing slashes)
    this.path = pathStr ? pathStr.replace(/^\/|\/$/g, '').split('/') : [];
  }
}

// Mock Database Instance
const databaseInstance = {};

function getDatabase() {
  return databaseInstance;
}

function ref(db, pathStr = '') {
  return new MockRef(pathStr);
}

// Resolve a path within the DB object
function resolvePath(obj, pathArray) {
  let current = obj;
  for (const part of pathArray) {
    if (part === '') continue;
    if (current[part] === undefined) {
      current[part] = {};
    }
    current = current[part];
  }
  return current;
}

// Mock Snapshot
class MockSnapshot {
  constructor(data) {
    this._data = data;
  }
  val() {
    return this._data;
  }
  exists() {
    return this._data !== undefined && this._data !== null;
  }
}

async function get(mockRef) {
  const dbData = readDB();
  let current = dbData;
  for (const part of mockRef.path) {
    if (part === '') continue;
    if (current && current[part] !== undefined) {
      current = current[part];
    } else {
      current = undefined;
      break;
    }
  }
  return new MockSnapshot(current);
}

async function set(mockRef, value) {
  const dbData = readDB();
  if (mockRef.path.length === 0) {
    writeDB(value);
    return;
  }
  
  let current = dbData;
  for (let i = 0; i < mockRef.path.length - 1; i++) {
    const part = mockRef.path[i];
    if (current[part] === undefined) {
      current[part] = {};
    }
    current = current[part];
  }
  
  const lastPart = mockRef.path[mockRef.path.length - 1];
  current[lastPart] = value;
  writeDB(dbData);
}

async function update(mockRef, values) {
  const dbData = readDB();
  let current = dbData;
  for (let i = 0; i < mockRef.path.length; i++) {
    const part = mockRef.path[i];
    if (current[part] === undefined) {
      current[part] = {};
    }
    current = current[part];
  }
  
  Object.assign(current, values);
  writeDB(dbData);
}

async function push(mockRef, value) {
  const dbData = readDB();
  let current = dbData;
  for (let i = 0; i < mockRef.path.length; i++) {
    const part = mockRef.path[i];
    if (current[part] === undefined) {
      current[part] = {};
    }
    current = current[part];
  }
  
  // Generate random mock key
  const newKey = 'key_' + Math.random().toString(36).substr(2, 9);
  if (Array.isArray(current)) {
    current.push(value);
  } else {
    current[newKey] = value;
  }
  
  writeDB(dbData);
  return { key: newKey };
}

module.exports = {
  getDatabase,
  ref,
  get,
  set,
  update,
  push
};
