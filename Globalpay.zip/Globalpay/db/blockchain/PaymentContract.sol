// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/**
 * @title PaymentContract
 * @dev Manages secure cross-border, multi-currency ledger payments on Ethereum.
 * @notice Created by kodam shishir bhagath
 */
contract PaymentContract {
    
    struct PaymentReceipt {
        bytes32 transactionId;
        string fromAccount;
        string toAccount;
        uint256 amount;
        string fromCurrency;
        string toCurrency;
        uint256 convertedAmount;
        uint256 rate; // Scaled by 1e6 (6 decimals)
        uint256 timestamp;
        bool success;
    }

    // Mapping from transaction ID hash to Payment Receipt
    mapping(bytes32 => PaymentReceipt) public receipts;
    
    // Total transactions processed count
    uint256 public totalTransactions;

    // Event emitted when a payment is processed on the ledger
    event PaymentProcessed(
        bytes32 indexed transactionId,
        string fromAccount,
        string toAccount,
        uint256 amount,
        string fromCurrency,
        string toCurrency,
        uint256 convertedAmount,
        uint256 timestamp
    );

    /**
     * @dev Process a cross-border multi-currency payment.
     * @param fromAccount Sender account string.
     * @param toAccount Recipient account string.
     * @param amount Sent amount in base currency.
     * @param fromCurrency Source currency identifier (e.g. "INR").
     * @param toCurrency Destination currency identifier (e.g. "USD").
     * @param convertedAmount Converted amount in target currency.
     * @param rate Conversion rate scaled by 1e6.
     * @return transactionId The generated hash of the blockchain transaction.
     */
    function processCrossBorderPayment(
        string memory fromAccount,
        string memory toAccount,
        uint256 amount,
        string memory fromCurrency,
        string memory toCurrency,
        uint256 convertedAmount,
        uint256 rate
    ) public returns (bytes32 transactionId) {
        
        // Generate a pseudo-random transaction hash inside smart contract
        transactionId = keccak256(
            abi.encodePacked(
                fromAccount,
                toAccount,
                amount,
                fromCurrency,
                toCurrency,
                block.timestamp,
                totalTransactions
            )
        );

        // Store receipt details in blockchain state
        receipts[transactionId] = PaymentReceipt({
            transactionId: transactionId,
            fromAccount: fromAccount,
            toAccount: toAccount,
            amount: amount,
            fromCurrency: fromCurrency,
            toCurrency: toCurrency,
            convertedAmount: convertedAmount,
            rate: rate,
            timestamp: block.timestamp,
            success: true
        });

        totalTransactions += 1;

        // Emit receipt event to block listeners
        emit PaymentProcessed(
            transactionId,
            fromAccount,
            toAccount,
            amount,
            fromCurrency,
            toCurrency,
            convertedAmount,
            block.timestamp
        );

        return transactionId;
    }
}
