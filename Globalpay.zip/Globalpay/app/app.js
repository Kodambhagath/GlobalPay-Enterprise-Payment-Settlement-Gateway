/* ==========================================================================
   GoldPay Application Engine
   Author: kodam shishir bhagath
   ========================================================================== */

// Base Server URL
const API_BASE = '/api';

// State flags
let currentAccount = null;
let currentScreen = 'screen-login';
let selectedRecipient = null;
let selectedCountry = null;
let qrTimerInterval = null;

// Offline Simulation Flag & Mock Database
let isOfflineMode = false;

const DEFAULT_LOCAL_DB = {
  accounts: {
    "987654321098": {
      accountNumber: "987654321098",
      owner: "Kodam Shishir Bhagath",
      balance: 150000.00,
      currency: "INR",
      flag: "🇮🇳",
      balancePassword: "12345567",
      paymentPassword: "123455678"
    },
    "112233445566": {
      accountNumber: "112233445566",
      owner: "Sample Number",
      balance: 25000.00,
      currency: "USD",
      flag: "🇺🇸",
      balancePassword: "12345567",
      paymentPassword: "123455678"
    }
  },
  transactions: [
    {
      txHash: "0x7a4df14a902388dc01a88bcf04051a",
      blockNumber: 18492021,
      timestamp: new Date(Date.now() - 3600000 * 2).toISOString(), // 2 hours ago
      fromAccount: "987654321098",
      toAccount: "112233445566",
      recipientName: "Sample Number",
      amount: 1500.00,
      fromCurrency: "INR",
      toCurrency: "USD",
      convertedAmount: 18.00,
      rate: 0.012,
      status: "SUCCESS"
    }
  ],
  qrCodes: {}
};

// 180 countries database with accurate ISO codes, native emojis, currency symbols, and exchange rates
const COUNTRIES_DATABASE = [
  { name: "India", code: "INR", symbol: "₹", flag: "🇮🇳", rate: 1.0 },
  { name: "United States", code: "USD", symbol: "$", flag: "🇺🇸", rate: 0.012 },
  { name: "United Kingdom", code: "GBP", symbol: "£", flag: "🇬🇧", rate: 0.0093 },
  { name: "European Union", code: "EUR", symbol: "€", flag: "🇪🇺", rate: 0.011 },
  { name: "Japan", code: "JPY", symbol: "¥", flag: "🇯🇵", rate: 1.85 },
  { name: "Canada", code: "CAD", symbol: "$", flag: "🇨🇦", rate: 0.016 },
  { name: "Australia", code: "AUD", symbol: "$", flag: "🇦🇺", rate: 0.018 },
  { name: "Switzerland", code: "CHF", symbol: "Fr", flag: "🇨🇭", rate: 0.011 },
  { name: "China", code: "CNY", symbol: "¥", flag: "🇨🇳", rate: 0.086 },
  { name: "New Zealand", code: "NZD", symbol: "$", flag: "🇳🇿", rate: 0.02 },
  { name: "Singapore", code: "SGD", symbol: "$", flag: "🇸🇬", rate: 0.016 },
  { name: "Hong Kong", code: "HKD", symbol: "$", flag: "🇭🇰", rate: 0.093 },
  { name: "South Korea", code: "KRW", symbol: "₩", flag: "🇰🇷", rate: 16.3 },
  { name: "Russia", code: "RUB", symbol: "₽", flag: "🇷🇺", rate: 1.1 },
  { name: "South Africa", code: "ZAR", symbol: "R", flag: "🇿🇦", rate: 0.22 },
  { name: "Brazil", code: "BRL", symbol: "R$", flag: "🇧🇷", rate: 0.06 },
  { name: "Mexico", code: "MXN", symbol: "$", flag: "🇲🇽", rate: 0.2 },
  { name: "Saudi Arabia", code: "SAR", symbol: "SR", flag: "🇸🇦", rate: 0.045 },
  { name: "United Arab Emirates", code: "AED", symbol: "د.إ", flag: "🇦🇪", rate: 0.044 },
  { name: "Turkey", code: "TRY", symbol: "₺", flag: "🇹🇷", rate: 0.4 },
  { name: "Argentina", code: "ARS", symbol: "$", flag: "🇦🇷", rate: 10.9 },
  { name: "Sweden", code: "SEK", symbol: "kr", flag: "🇸🇪", rate: 0.13 },
  { name: "Norway", code: "NOK", symbol: "kr", flag: "🇳🇴", rate: 0.13 },
  { name: "Denmark", code: "DKK", symbol: "kr", flag: "🇩🇰", rate: 0.082 },
  { name: "Israel", code: "ILS", symbol: "₪", flag: "🇮🇱", rate: 0.044 },
  { name: "Egypt", code: "EGP", symbol: "E£", flag: "🇪🇬", rate: 0.57 },
  { name: "Indonesia", code: "IDR", symbol: "Rp", flag: "🇮🇩", rate: 191.0 },
  { name: "Malaysia", code: "MYR", symbol: "RM", flag: "🇲🇾", rate: 0.056 },
  { name: "Philippines", code: "PHP", symbol: "₱", flag: "🇵🇭", rate: 0.68 },
  { name: "Thailand", code: "THB", symbol: "฿", flag: "🇹🇭", rate: 0.43 },
  { name: "Vietnam", code: "VND", symbol: "₫", flag: "🇻🇳", rate: 305.0 },
  { name: "Pakistan", code: "PKR", symbol: "₨", flag: "🇵🇰", rate: 3.34 },
  { name: "Bangladesh", code: "BDT", symbol: "৳", flag: "🇧🇩", rate: 1.4 },
  { name: "Sri Lanka", code: "LKR", symbol: "₨", flag: "🇱🇰", rate: 3.6 },
  { name: "Nepal", code: "NPR", symbol: "₨", flag: "🇳🇵", rate: 1.6 },
  { name: "Afghanistan", code: "AFN", symbol: "Af", flag: "🇦🇫", rate: 0.84 },
  { name: "Albania", code: "ALL", symbol: "Lek", flag: "🇦🇱", rate: 1.13 },
  { name: "Algeria", code: "DZD", symbol: "DA", flag: "🇩🇿", rate: 1.61 },
  { name: "Andorra", code: "EUR", symbol: "€", flag: "🇦🇩", rate: 0.011 },
  { name: "Angola", code: "AOA", symbol: "Kz", flag: "🇦🇴", rate: 10.1 },
  { name: "Armenia", code: "AMD", symbol: "֏", flag: "🇦🇲", rate: 4.67 },
  { name: "Austria", code: "EUR", symbol: "€", flag: "🇦🇹", rate: 0.011 },
  { name: "Azerbaijan", code: "AZN", symbol: "₼", flag: "🇦🇿", rate: 0.02 },
  { name: "Bahamas", code: "BSD", symbol: "$", flag: "🇧🇸", rate: 0.012 },
  { name: "Bahrain", code: "BHD", symbol: "BD", flag: "🇧🇭", rate: 0.0045 },
  { name: "Barbados", code: "BBD", symbol: "$", flag: "🇧🇧", rate: 0.024 },
  { name: "Belarus", code: "BYN", symbol: "Br", flag: "🇧🇾", rate: 0.039 },
  { name: "Belgium", code: "EUR", symbol: "€", flag: "🇧🇪", rate: 0.011 },
  { name: "Belize", code: "BZD", symbol: "$", flag: "🇧🇿", rate: 0.024 },
  { name: "Benin", code: "XOF", symbol: "CFA", flag: "🇧🇯", rate: 7.2 },
  { name: "Bhutan", code: "BTN", symbol: "Nu.", flag: "🇧🇹", rate: 1.0 },
  { name: "Bolivia", code: "BOB", symbol: "Bs.", fill: "#fff", flag: "🇧🇴", rate: 0.083 },
  { name: "Bosnia & Herzegovina", code: "BAM", symbol: "KM", flag: "🇧🇦", rate: 0.022 },
  { name: "Botswana", code: "BWP", symbol: "P", flag: "🇧🇼", rate: 0.16 },
  { name: "Brunei", code: "BND", symbol: "$", flag: "🇧🇳", rate: 0.016 },
  { name: "Bulgaria", code: "BGN", symbol: "лв", flag: "🇧🇬", rate: 0.022 },
  { name: "Burkina Faso", code: "XOF", symbol: "CFA", flag: "🇧🇫", rate: 7.2 },
  { name: "Burundi", code: "BIF", symbol: "FBu", flag: "🇧🇮", rate: 34.3 },
  { name: "Cambodia", code: "KHR", symbol: "៛", flag: "🇰🇭", rate: 49.3 },
  { name: "Cameroon", code: "XAF", symbol: "FCFA", flag: "🇨🇲", rate: 7.2 },
  { name: "Cape Verde", code: "CVE", symbol: "$", flag: "🇨🇻", rate: 1.2 },
  { name: "Central African Rep.", code: "XAF", symbol: "FCFA", flag: "🇨🇫", rate: 7.2 },
  { name: "Chad", code: "XAF", symbol: "FCFA", flag: "🇹🇩", rate: 7.2 },
  { name: "Chile", code: "CLP", symbol: "$", flag: "🇨🇱", rate: 11.2 },
  { name: "Colombia", code: "COP", symbol: "$", flag: "🇨🇴", rate: 47.0 },
  { name: "Comoros", code: "KMF", symbol: "CF", flag: "🇰🇲", rate: 5.4 },
  { name: "Congo", code: "CDF", symbol: "FC", flag: "🇨🇬", rate: 33.6 },
  { name: "Costa Rica", code: "CRC", symbol: "₡", flag: "🇨🇷", rate: 6.2 },
  { name: "Croatia", code: "EUR", symbol: "€", flag: "🇭🇷", rate: 0.011 },
  { name: "Cuba", code: "CUP", symbol: "$", flag: "🇨🇺", rate: 0.29 },
  { name: "Cyprus", code: "EUR", symbol: "€", flag: "🇨🇾", rate: 0.011 },
  { name: "Czech Republic", code: "CZK", symbol: "Kč", flag: "🇨🇿", rate: 0.28 },
  { name: "Djibouti", code: "DJF", symbol: "Fdj", flag: "🇩🇯", rate: 2.1 },
  { name: "Dominica", code: "XCD", symbol: "$", flag: "🇩🇲", rate: 0.032 },
  { name: "Dominican Republic", code: "DOP", symbol: "$", flag: "🇩🇴", rate: 0.7 },
  { name: "Ecuador", code: "USD", symbol: "$", flag: "🇪🇨", rate: 0.012 },
  { name: "El Salvador", code: "USD", symbol: "$", flag: "🇸🇻", rate: 0.012 },
  { name: "Equatorial Guinea", code: "XAF", symbol: "FCFA", flag: "🇬🇶", rate: 7.2 },
  { name: "Eritrea", code: "ERN", symbol: "Nfk", flag: "🇪🇷", rate: 0.18 },
  { name: "Estonia", code: "EUR", symbol: "€", flag: "🇪🇪", rate: 0.011 },
  { name: "Eswatini", code: "SZL", symbol: "L", flag: "🇸🇿", rate: 0.22 },
  { name: "Ethiopia", code: "ETB", symbol: "Br", flag: "🇪🇹", rate: 0.69 },
  { name: "Fiji", code: "FJD", symbol: "$", flag: "🇫🇯", rate: 0.027 },
  { name: "Finland", code: "EUR", symbol: "€", flag: "🇫🇮", rate: 0.011 },
  { name: "France", code: "EUR", symbol: "€", flag: "🇫🇷", rate: 0.011 },
  { name: "Gabon", code: "XAF", symbol: "FCFA", flag: "🇬🇦", rate: 7.2 },
  { name: "Gambia", code: "GMD", symbol: "D", flag: "🇬🇲", rate: 0.81 },
  { name: "Georgia", code: "GEL", symbol: "₾", flag: "🇬🇪", rate: 0.032 },
  { name: "Germany", code: "EUR", symbol: "€", flag: "🇩🇪", rate: 0.011 },
  { name: "Ghana", code: "GHS", symbol: "GH₵", flag: "🇬🇭", rate: 0.15 },
  { name: "Greece", code: "EUR", symbol: "€", flag: "🇬🇷", rate: 0.011 },
  { name: "Grenada", code: "XCD", symbol: "$", flag: "🇬🇩", rate: 0.032 },
  { name: "Guatemala", code: "GTQ", symbol: "Q", flag: "🇬🇹", rate: 0.093 },
  { name: "Guinea", code: "GNF", symbol: "FG", flag: "🇬🇳", rate: 103.0 },
  { name: "Guinea-Bissau", code: "XOF", symbol: "CFA", flag: "🇬🇼", rate: 7.2 },
  { name: "Guyana", code: "GYD", symbol: "$", flag: "🇬🇾", rate: 2.5 },
  { name: "Haiti", code: "HTG", symbol: "G", flag: "🇭🇹", rate: 1.58 },
  { name: "Honduras", code: "HNL", symbol: "L", flag: "🇭🇳", rate: 0.3 },
  { name: "Hungary", code: "HUF", symbol: "Ft", flag: "🇭🇺", rate: 4.25 },
  { name: "Iceland", code: "ISK", symbol: "kr", flag: "🇮🇸", rate: 1.66 },
  { name: "Iran", code: "IRR", symbol: "﷼", flag: "🇮🇷", rate: 505.0 },
  { name: "Iraq", code: "IQD", symbol: "IQD", flag: "🇮🇶", rate: 15.7 },
  { name: "Ireland", code: "EUR", symbol: "€", flag: "🇮🇪", rate: 0.011 },
  { name: "Italy", code: "EUR", symbol: "€", flag: "🇮🇹", rate: 0.011 },
  { name: "Jamaica", code: "JMD", symbol: "$", flag: "🇯🇲", rate: 1.86 },
  { name: "Jordan", code: "JOD", symbol: "JD", flag: "🇯🇴", rate: 0.0085 },
  { name: "Kazakhstan", code: "KZT", symbol: "₸", flag: "🇰🇿", rate: 5.4 },
  { name: "Kenya", code: "KES", symbol: "KSh", flag: "🇰🇪", rate: 1.6 },
  { name: "Kiribati", code: "AUD", symbol: "$", flag: "🇰🇮", rate: 0.018 },
  { name: "Kuwait", code: "KWD", symbol: "KD", flag: "🇰🇼", rate: 0.0037 },
  { name: "Kyrgyzstan", code: "KGS", symbol: "сом", flag: "🇰🇬", rate: 1.07 },
  { name: "Laos", code: "LAK", symbol: "₭", flag: "🇱🇦", rate: 250.0 },
  { name: "Latvia", code: "EUR", symbol: "€", flag: "🇱🇻", rate: 0.011 },
  { name: "Lebanon", code: "LBP", symbol: "L£", flag: "🇱🇧", rate: 180.0 },
  { name: "Lesotho", code: "LSL", symbol: "L", flag: "🇱🇸", rate: 0.22 },
  { name: "Liberia", code: "LRD", symbol: "$", flag: "🇱🇷", rate: 2.3 },
  { name: "Libya", code: "LYD", symbol: "LD", flag: "🇱🇾", rate: 0.058 },
  { name: "Liechtenstein", code: "CHF", symbol: "Fr", flag: "🇱🇮", rate: 0.011 },
  { name: "Lithuania", code: "EUR", symbol: "€", flag: "🇱🇹", rate: 0.011 },
  { name: "Luxembourg", code: "EUR", symbol: "€", flag: "🇱🇺", rate: 0.011 },
  { name: "Madagascar", code: "MGA", symbol: "Ar", flag: "🇲🇬", rate: 54.0 },
  { name: "Malawi", code: "MWK", symbol: "MK", flag: "🇲🇼", rate: 20.4 },
  { name: "Maldives", code: "MVR", symbol: "Rf", flag: "🇲🇻", rate: 0.18 },
  { name: "Mali", code: "XOF", symbol: "CFA", flag: "🇲🇱", rate: 7.2 },
  { name: "Malta", code: "EUR", symbol: "€", flag: "🇲🇹", rate: 0.011 },
  { name: "Marshall Islands", code: "USD", symbol: "$", flag: "🇲🇭", rate: 0.012 },
  { name: "Mauritania", code: "MRU", symbol: "UM", flag: "🇲🇷", rate: 0.47 },
  { name: "Mauritius", code: "MUR", symbol: "₨", flag: "🇲🇺", rate: 0.55 },
  { name: "Micronesia", code: "USD", symbol: "$", flag: "🇫🇲", rate: 0.012 },
  { name: "Moldova", code: "MDL", symbol: "L", flag: "🇲🇩", rate: 0.21 },
  { name: "Monaco", code: "EUR", symbol: "€", flag: "🇲🇨", rate: 0.011 },
  { name: "Mongolia", code: "MNT", symbol: "₮", flag: "🇲🇳", rate: 41.3 },
  { name: "Montenegro", code: "EUR", symbol: "€", flag: "🇲🇪", rate: 0.011 },
  { name: "Morocco", code: "MAD", symbol: "DH", flag: "🇲🇦", rate: 0.12 },
  { name: "Mozambique", code: "MZN", symbol: "MT", flag: "🇲🇿", rate: 0.77 },
  { name: "Myanmar", code: "MMK", symbol: "K", flag: "🇲🇲", rate: 25.2 },
  { name: "Namibia", code: "NAD", symbol: "$", flag: "🇳🇦", rate: 0.22 },
  { name: "Nauru", code: "AUD", symbol: "$", flag: "🇳🇷", rate: 0.018 },
  { name: "Niger", code: "XOF", symbol: "CFA", flag: "🇳🇪", rate: 7.2 },
  { name: "Nigeria", code: "NGN", symbol: "₦", flag: "🇳🇬", rate: 18.0 },
  { name: "North Korea", code: "KPW", symbol: "₩", flag: "🇰🇵", rate: 10.8 },
  { name: "North Macedonia", code: "MKD", symbol: "ден", flag: "🇲🇰", rate: 0.68 },
  { name: "Oman", code: "OMR", symbol: "RO", flag: "🇴🇲", rate: 0.0046 },
  { name: "Palau", code: "USD", symbol: "$", flag: "🇵🇼", rate: 0.012 },
  { name: "Palestine", code: "ILS", symbol: "₪", flag: "🇵🇸", rate: 0.044 },
  { name: "Panama", code: "PAB", symbol: "B/.", flag: "🇵🇦", rate: 0.012 },
  { name: "Papua New Guinea", code: "PGK", symbol: "K", flag: "🇵🇬", rate: 0.045 },
  { name: "Paraguay", code: "PYG", symbol: "₲", flag: "🇵🇾", rate: 89.0 },
  { name: "Peru", code: "PEN", symbol: "S/.", flag: "🇵🇪", rate: 0.045 },
  { name: "Philippines", code: "PHP", symbol: "₱", flag: "🇵🇭", rate: 0.68 },
  { name: "Poland", code: "PLN", symbol: "zł", flag: "🇵🇱", rate: 0.047 },
  { name: "Portugal", code: "EUR", symbol: "€", flag: "🇵🇹", rate: 0.011 },
  { name: "Qatar", code: "QAR", symbol: "QR", flag: "🇶🇦", rate: 0.044 },
  { name: "Romania", code: "RON", symbol: "lei", flag: "🇷🇴", rate: 0.055 },
  { name: "Rwanda", code: "RWF", symbol: "FRw", flag: "🇷🇼", rate: 15.5 },
  { name: "Saint Kitts", code: "XCD", symbol: "$", flag: "🇰🇳", rate: 0.032 },
  { name: "Saint Lucia", code: "XCD", symbol: "$", flag: "🇱🇨", rate: 0.032 },
  { name: "Saint Vincent", code: "XCD", symbol: "$", flag: "🇻🇨", rate: 0.032 },
  { name: "Samoa", code: "WST", symbol: "T", flag: "🇼🇸", rate: 0.033 },
  { name: "San Marino", code: "EUR", symbol: "€", flag: "🇸🇲", rate: 0.011 },
  { name: "Sao Tome", code: "STN", symbol: "Db", flag: "🇸🇹", rate: 0.27 },
  { name: "Senegal", code: "XOF", symbol: "CFA", flag: "🇸🇳", rate: 7.2 },
  { name: "Serbia", code: "RSD", symbol: "din", flag: "🇷🇸", rate: 1.28 },
  { name: "Seychelles", code: "SCR", symbol: "₨", flag: "🇸🇨", rate: 0.16 },
  { name: "Sierra Leone", code: "SLE", symbol: "Le", flag: "🇸🇱", rate: 270.0 },
  { name: "Slovakia", code: "EUR", symbol: "€", flag: "🇸🇰", rate: 0.011 },
  { name: "Slovenia", code: "EUR", symbol: "€", flag: "🇸🇮", rate: 0.011 },
  { name: "Solomon Islands", code: "SBD", symbol: "$", flag: "🇸🇧", rate: 0.1 },
  { name: "Somalia", code: "SOS", symbol: "Sh.So.", flag: "🇸🇴", rate: 6.8 },
  { name: "South Sudan", code: "SSP", symbol: "£", flag: "🇸🇸", rate: 1.56 },
  { name: "Spain", code: "EUR", symbol: "€", flag: "🇪🇸", rate: 0.011 },
  { name: "Sudan", code: "SDG", symbol: "LS", flag: "🇸🇩", rate: 7.2 },
  { name: "Suriname", code: "SRD", symbol: "$", flag: "🇸🇷", rate: 0.42 },
  { name: "Tajikistan", code: "TJS", symbol: "SM", flag: "🇹🇯", rate: 0.13 },
  { name: "Tanzania", code: "TZS", symbol: "TSh", flag: "🇹🇿", rate: 31.2 },
  { name: "Timor-Leste", code: "USD", symbol: "$", flag: "🇹🇱", rate: 0.012 },
  { name: "Togo", code: "XOF", symbol: "CFA", flag: "🇹🇬", rate: 7.2 },
  { name: "Tonga", code: "TOP", symbol: "T$", flag: "🇹🇴", rate: 0.028 },
  { name: "Trinidad & Tobago", code: "TTD", symbol: "$", flag: "🇹🇹", rate: 0.081 },
  { name: "Tunisia", code: "TND", symbol: "DT", flag: "🇹🇳", rate: 0.037 },
  { name: "Turkmenistan", code: "TMT", symbol: "T", flag: "🇹🇲", rate: 0.042 },
  { name: "Tuvalu", code: "AUD", symbol: "$", flag: "🇹🇻", rate: 0.018 },
  { name: "Uganda", code: "UGX", symbol: "USh", flag: "🇺🇬", rate: 45.0 },
  { name: "Ukraine", code: "UAH", symbol: "₴", flag: "🇺🇦", rate: 0.49 },
  { name: "Uruguay", code: "UYU", symbol: "$", flag: "🇺🇾", rate: 0.47 },
  { name: "Uzbekistan", code: "UZS", symbol: "so'm", flag: "🇺🇿", rate: 152.0 },
  { name: "Vanuatu", code: "VUV", symbol: "VT", flag: "🇻🇺", rate: 1.44 },
  { name: "Vatican City", code: "EUR", symbol: "€", flag: "🇻🇦", rate: 0.011 },
  { name: "Venezuela", code: "VES", symbol: "Bs.S", flag: "🇻🇪", rate: 0.43 },
  { name: "Yemen", code: "YER", symbol: "﷼", flag: "🇾🇪", rate: 3.0 },
  { name: "Zambia", code: "ZMW", symbol: "ZK", flag: "🇿🇲", rate: 0.31 },
  { name: "Zimbabwe", code: "ZWG", symbol: "ZiG", flag: "🇿🇼", rate: 0.16 }
];

// Initialize DOM Bindings
document.addEventListener('DOMContentLoaded', () => {
  detectServerConnection();
  setupClock();
  setupCardFlips();
  setupNavigation();
  setupLoginHandlers();
  setupDashboardHandlers();
  setupToNumberHandlers();
  setupChatHandlers();
  setupConversionHandlers();
  setupQRHandlers();
  setupCountrySearch();
  setupSoundMutes();
});

// Clock Updater
function setupClock() {
  const updateClock = () => {
    const clockEl = document.getElementById('status-clock');
    if (!clockEl) return;
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const mins = now.getMinutes().toString().padStart(2, '0');
    clockEl.textContent = `${hours}:${mins}`;
  };
  updateClock();
  setInterval(updateClock, 1000);
}

// 3D Credit Card interactive flips
function setupCardFlips() {
  const cardTrigger = document.getElementById('login-card-trigger');
  const cardElement = document.getElementById('3d-titanium-card');
  const accountSelect = document.getElementById('login-account-select');

  // Sync profile details onto credit card face when select dropdown changes
  accountSelect.addEventListener('change', () => {
    const val = accountSelect.value;
    document.getElementById('card-account-number-front').textContent = val;
    if (val === '987654321098') {
      document.getElementById('card-owner-front').textContent = "KODAM SHISHIR BHAGATH";
    } else {
      document.getElementById('card-owner-front').textContent = "SAMPLE NUMBER";
    }
  });

  // Flip credit card on click
  if (cardTrigger && cardElement) {
    cardTrigger.addEventListener('click', () => {
      cardElement.classList.toggle('flipped');
    });
  }
}

// Resilient API Fetch Helper: falls back to LocalStorage if server is down or file:// is used
async function requestAPI(url, options = {}) {
  // If we already know we're offline, run offline API directly
  if (isOfflineMode) {
    return runOfflineAPI(url, options);
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000); // 2 sec timeout
    
    const res = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(timeoutId);
    
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Server HTTP error');
    }
    return await res.json();
  } catch (err) {
    console.warn(`[GoldPay Engine] Server fetch failed (${err.message}). Switching to Local Offline Database.`);
    setOfflineMode(true);
    return runOfflineAPI(url, options);
  }
}

// Detect connection initially
async function detectServerConnection() {
  const badge = document.getElementById('ledger-connection-badge');
  const badgeTxt = document.getElementById('connection-text');
  
  if (window.location.protocol === 'file:') {
    setOfflineMode(true);
    return;
  }

  try {
    const check = await fetch('/api/accounts/987654321098');
    if (check.ok) {
      setOfflineMode(false);
    } else {
      setOfflineMode(true);
    }
  } catch (e) {
    setOfflineMode(true);
  }
}

function setOfflineMode(offline) {
  isOfflineMode = offline;
  const badge = document.getElementById('ledger-connection-badge');
  const badgeTxt = document.getElementById('connection-text');
  
  if (!badge || !badgeTxt) return;

  if (offline) {
    badge.className = "ledger-indicator offline";
    badgeTxt.textContent = "OFFLINE DB";
    // Initialize LocalStorage database if empty
    if (!localStorage.getItem('goldpay_db')) {
      localStorage.setItem('goldpay_db', JSON.stringify(DEFAULT_LOCAL_DB));
    }
  } else {
    badge.className = "ledger-indicator connected";
    badgeTxt.textContent = "SOLIDITY SERVER";
  }
}

// Local Database Controller mirroring server APIs on LocalStorage
function runOfflineAPI(url, options = {}) {
  const dbData = JSON.parse(localStorage.getItem('goldpay_db')) || DEFAULT_LOCAL_DB;
  const method = options.method || 'GET';
  const body = options.body ? JSON.parse(options.body) : {};

  // Match: /api/accounts/:id
  const accountMatch = url.match(/\/api\/accounts\/(\d+)/);
  if (accountMatch && method === 'GET') {
    const accNum = accountMatch[1];
    const acc = dbData.accounts[accNum];
    if (acc) {
      return { success: true, account: acc };
    } else {
      return { success: false, error: 'Account not found' };
    }
  }

  // Match: /api/balance
  if (url.includes('/api/balance') && method === 'POST') {
    const { accountNumber, password } = body;
    const acc = dbData.accounts[accountNumber];
    if (!acc) return { success: false, error: 'Account not found' };
    if (acc.balancePassword !== password) return { success: false, error: 'Invalid password' };
    return { success: true, balance: acc.balance, currency: acc.currency };
  }

  // Match: /api/pay
  if (url.includes('/api/pay') && method === 'POST') {
    const { fromAccount, toAccount, amount, targetCurrency, rate, password } = body;
    const sender = dbData.accounts[fromAccount];
    
    if (!sender) return { success: false, error: 'Sender not found' };
    if (sender.paymentPassword !== password) return { success: false, error: 'Incorrect PIN' };
    
    const numAmount = parseFloat(amount);
    if (sender.balance < numAmount) return { success: false, error: 'Insufficient funds' };

    // Process balances
    sender.balance -= numAmount;
    
    let recipientName = `User (${toAccount})`;
    let targetAcc = dbData.accounts[toAccount];
    
    const convRate = parseFloat(rate || 1.0);
    const convertedAmount = numAmount * convRate;

    if (targetAcc) {
      recipientName = targetAcc.owner;
      targetAcc.balance += convertedAmount;
    }

    // Save transaction hash details
    const txHash = `0x7a4d${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`;
    const blockNumber = 18492000 + Math.floor(Math.random() * 5000);

    const newTx = {
      txHash,
      blockNumber,
      timestamp: new Date().toISOString(),
      fromAccount,
      toAccount,
      recipientName,
      amount: numAmount,
      fromCurrency: sender.currency,
      toCurrency: targetCurrency,
      convertedAmount,
      rate: convRate,
      status: 'SUCCESS'
    };

    dbData.transactions.unshift(newTx);
    localStorage.setItem('goldpay_db', JSON.stringify(dbData));

    return {
      success: true,
      receipt: newTx,
      blockchain: {
        transactionHash: txHash,
        blockNumber,
        contractVerified: true
      }
    };
  }

  // Match: /api/transactions/:id
  const txMatch = url.match(/\/api\/transactions\/(\d+)/);
  if (txMatch && method === 'GET') {
    const accNum = txMatch[1];
    const filtered = dbData.transactions.filter(tx => tx.fromAccount === accNum || tx.toAccount === accNum);
    return { success: true, history: filtered };
  }

  // Match: /api/qr/create
  if (url.includes('/api/qr/create') && method === 'POST') {
    const { type, accountNumber, amount, currency, expiresAt } = body;
    const qrId = 'qr_' + Math.random().toString(36).substr(2, 9);
    const qrConfig = {
      qrId,
      type,
      accountNumber,
      amount: type === 'FIXED' ? parseFloat(amount) : null,
      currency: currency || 'INR',
      expiresAt: expiresAt || null,
      createdAt: new Date().toISOString()
    };
    dbData.qrCodes[qrId] = qrConfig;
    localStorage.setItem('goldpay_db', JSON.stringify(dbData));
    return { success: true, qr: qrConfig };
  }

  // Match: /api/qr/:id
  const qrFetchMatch = url.match(/\/api\/qr\/(qr_[a-z0-9]+)/);
  if (qrFetchMatch && method === 'GET') {
    const qrId = qrFetchMatch[1];
    const qr = dbData.qrCodes[qrId];
    if (qr) {
      return { success: true, qr };
    } else {
      return { success: false, error: 'QR Code not found' };
    }
  }

  return { success: false, error: 'API route mock not mapped' };
}

// Text to Speech
function speakConfirmation(text) {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.volume = 1.0;
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    
    const voices = window.speechSynthesis.getVoices();
    const englishVoice = voices.find(voice => voice.lang.includes('en') && (voice.name.includes('Google') || voice.name.includes('Natural')));
    if (englishVoice) {
      utterance.voice = englishVoice;
    }
    window.speechSynthesis.speak(utterance);
  }
}

// routing screens
function showScreen(screenId) {
  const screens = document.querySelectorAll('.screen');
  screens.forEach(screen => {
    screen.classList.remove('active');
  });

  const activeScreen = document.getElementById(screenId);
  activeScreen.classList.add('active');
  currentScreen = screenId;
  
  if (screenId !== 'screen-myqr' && qrTimerInterval) {
    clearInterval(qrTimerInterval);
  }
}

function setupNavigation() {
  const backToDashBtns = document.querySelectorAll('.btn-to-dashboard');
  backToDashBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      showScreen('screen-dashboard');
      refreshDashboard();
    });
  });
}

// ========================== LOGIN HANDLERS ==========================
function setupLoginHandlers() {
  const loginSelect = document.getElementById('login-account-select');
  const btnLogin = document.getElementById('btn-login');

  const performLogin = async (accNum) => {
    try {
      const data = await requestAPI(`${API_BASE}/accounts/${accNum}`);
      if (data.success) {
        currentAccount = data.account;
        
        // Populate UI
        document.getElementById('dash-user-name').textContent = currentAccount.owner;
        document.getElementById('dash-account-number').textContent = `A/C ${currentAccount.accountNumber}`;
        document.getElementById('user-badge-initials').textContent = currentAccount.owner.split(' ').map(n=>n[0]).join('');
        document.getElementById('txt-display-balance').textContent = "₹ ••••••••";
        document.getElementById('btn-toggle-balance-view').textContent = "Show Balance";
        
        showScreen('screen-dashboard');
        refreshDashboard();
      } else {
        alert("Authorization Error: " + data.error);
      }
    } catch (e) {
      alert("Error logging in: " + e.message);
    }
  };

  btnLogin.addEventListener('click', () => {
    performLogin(loginSelect.value);
  });

  // Credit card trigger also logs user in after a cool flipping delay
  const titaniumCard = document.getElementById('3d-titanium-card');
  document.getElementById('login-card-trigger').addEventListener('dblclick', () => {
    titaniumCard.classList.add('flipped');
    setTimeout(() => {
      performLogin(loginSelect.value);
    }, 900);
  });
}

// ========================== DASHBOARD HANDLERS ==========================
function setupDashboardHandlers() {
  const btnToggleBalance = document.getElementById('btn-toggle-balance-view');
  const btnCopyAccount = document.getElementById('btn-copy-account');
  const btnLogout = document.getElementById('btn-logout');
  const btnToNum = document.getElementById('dash-action-tonumber');
  const btnScan = document.getElementById('dash-action-scanner');
  const btnMyQr = document.getElementById('dash-action-myqr');
  const btnContractCheck = document.getElementById('btn-blockchain-verify');

  // PIN modal details
  const modalBalance = document.getElementById('modal-balance-password');
  const pinInput = document.getElementById('input-balance-pin');
  const btnTogglePin = document.getElementById('btn-toggle-pin-visibility');
  const btnCancel = document.getElementById('btn-balance-cancel');
  const btnConfirm = document.getElementById('btn-balance-confirm');
  const bearWidget = document.getElementById('bear-widget');

  const eyeClosed = document.getElementById('eye-icon-closed');
  const eyeOpen = document.getElementById('eye-icon-open');

  btnToggleBalance.addEventListener('click', () => {
    if (btnToggleBalance.textContent === "Show Balance") {
      // Show PIN prompt modal
      modalBalance.style.display = 'flex';
      pinInput.value = '';
      btnConfirm.disabled = true;
      bearWidget.setAttribute('data-state', 'cover');
      pinInput.type = 'password';
      eyeClosed.style.display = 'block';
      eyeOpen.style.display = 'none';
    } else {
      // Re-hide balance
      document.getElementById('txt-display-balance').textContent = "₹ ••••••••";
      btnToggleBalance.textContent = "Show Balance";
    }
  });

  btnCopyAccount.addEventListener('click', () => {
    navigator.clipboard.writeText(currentAccount.accountNumber);
    alert("Account number copied to secure clipboard!");
  });

  btnLogout.addEventListener('click', () => {
    currentAccount = null;
    showScreen('screen-login');
  });

  pinInput.addEventListener('input', () => {
    btnConfirm.disabled = pinInput.value.length < 4;
  });

  btnTogglePin.addEventListener('click', () => {
    if (pinInput.type === 'password') {
      pinInput.type = 'text';
      eyeClosed.style.display = 'none';
      eyeOpen.style.display = 'block';
      bearWidget.setAttribute('data-state', 'peek');
    } else {
      pinInput.type = 'password';
      eyeClosed.style.display = 'block';
      eyeOpen.style.display = 'none';
      bearWidget.setAttribute('data-state', 'cover');
    }
  });

  btnCancel.addEventListener('click', () => {
    modalBalance.style.display = 'none';
  });

  btnConfirm.addEventListener('click', async () => {
    const pin = pinInput.value;
    try {
      const data = await requestAPI(`${API_BASE}/balance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accountNumber: currentAccount.accountNumber,
          password: pin
        })
      });

      if (data.success) {
        modalBalance.style.display = 'none';
        const symbol = getCurrencySymbol(data.currency);
        document.getElementById('txt-display-balance').textContent = `${symbol} ${data.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
        btnToggleBalance.textContent = "Hide Balance";
      } else {
        alert("Pin signature error: " + data.error);
      }
    } catch (e) {
      alert("Error verifying PIN: " + e.message);
    }
  });

  btnToNum.addEventListener('click', () => {
    showScreen('screen-tonumber');
    document.getElementById('input-recipient-number').value = '';
    document.getElementById('recipient-choice-popup').style.display = 'none';
  });

  btnScan.addEventListener('click', () => {
    showScreen('screen-scanner');
    document.getElementById('select-scan-simulation').value = '';
    document.getElementById('btn-execute-simulated-scan').disabled = true;
  });

  btnMyQr.addEventListener('click', () => {
    showScreen('screen-myqr');
    initializeMyQR();
  });

  btnContractCheck.addEventListener('click', () => {
    // Verified status check
    alert("Decentralized Solidity Contract Audit Status:\nFile Path: /db/blockchain/PaymentContract.sol\nState Verification: verifiedMethod processCrossBorderPayment confirmed on-chain.");
  });
}

async function refreshDashboard() {
  if (!currentAccount) return;
  
  // Height check
  const randomBlockHeight = 18492000 + Math.floor((Date.now() - 1718000000000) / 12000);
  document.getElementById('ledger-block-height').textContent = `BLOCK #${randomBlockHeight}`;

  try {
    const data = await requestAPI(`${API_BASE}/transactions/${currentAccount.accountNumber}`);
    const listElement = document.getElementById('tx-history-list');
    
    if (data.success && data.history.length > 0) {
      listElement.innerHTML = '';
      data.history.forEach(tx => {
        const item = document.createElement('div');
        item.className = 'tx-history-item';
        
        const isDebit = tx.fromAccount === currentAccount.accountNumber;
        const flag = isDebit ? getCountryFlag(tx.toCurrency) : getCountryFlag(tx.fromCurrency);
        const amountDisplay = isDebit 
          ? `- ₹${tx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` 
          : `+ ₹${tx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
          
        item.innerHTML = `
          <div class="tx-item-left">
            <div class="tx-icon-stamp">${flag}</div>
            <div class="tx-details">
              <h5>${isDebit ? 'Paid to ' + tx.recipientName : 'Received from ' + tx.fromAccount}</h5>
              <span>${new Date(tx.timestamp).toLocaleString()}</span>
            </div>
          </div>
          <div class="tx-item-right">
            <span class="tx-amount" style="color: ${isDebit ? '#f3f4f6' : '#10b981'}">${amountDisplay}</span>
            <div class="tx-currency-label">${tx.toCurrency} (${getCurrencySymbol(tx.toCurrency)})</div>
          </div>
        `;
        
        item.addEventListener('click', () => {
          showInvoiceDetails(tx);
        });
        
        listElement.appendChild(item);
      });
    } else {
      listElement.innerHTML = `<div class="ledger-empty-txt">No recorded blocks for account on-chain.</div>`;
    }
  } catch (err) {
    console.error("Error updating transaction list:", err);
  }
}

// ========================== TO NUMBER HANDLERS ==========================
function setupToNumberHandlers() {
  const inputNum = document.getElementById('input-recipient-number');
  const btnSample = document.getElementById('btn-sample-recipient');
  const popup = document.getElementById('recipient-choice-popup');
  const selectedLabel = document.getElementById('selected-recipient-label');

  inputNum.addEventListener('input', () => {
    const val = inputNum.value.trim();
    if (val.length >= 6) {
      selectedRecipient = val;
      selectedLabel.textContent = val;
      popup.style.display = 'block';
    } else {
      popup.style.display = 'none';
    }
  });

  btnSample.addEventListener('click', () => {
    selectedRecipient = '112233445566';
    selectedLabel.textContent = '112233445566';
    popup.style.display = 'block';
  });

  document.getElementById('btn-choose-pay').onclick = () => {
    startPaymentChat(selectedRecipient);
  };
  document.getElementById('btn-choose-qr').onclick = () => {
    startPaymentChat(selectedRecipient);
  };
}

// ========================== CHAT FLOW ==========================
function setupChatHandlers() {
  const btnTrigger = document.getElementById('btn-trigger-currency');
  const inputAmt = document.getElementById('input-payment-amount');
  const btnSubmit = document.getElementById('btn-chat-pay');
  const modal = document.getElementById('modal-currency-selector');

  btnTrigger.addEventListener('click', () => {
    modal.style.display = 'flex';
    document.getElementById('input-country-search').value = '';
    renderCountriesList(COUNTRIES_DATABASE);
  });

  inputAmt.addEventListener('input', () => {
    const val = parseFloat(inputAmt.value);
    btnSubmit.disabled = isNaN(val) || val <= 0;
  });

  btnSubmit.addEventListener('click', () => {
    const amountVal = parseFloat(inputAmt.value);
    
    // Simulate bubble output
    const amountBubble = document.getElementById('chat-amount-bubble');
    document.getElementById('txt-bubble-currency').textContent = selectedCountry.code;
    document.getElementById('txt-bubble-amount').textContent = amountVal.toFixed(2);
    amountBubble.style.display = 'flex';
    
    // Scroll chat down
    const scroller = document.getElementById('chat-scroller');
    scroller.scrollTop = scroller.scrollHeight;

    setTimeout(() => {
      openConversionScreen(amountVal);
    }, 850);
  });
}

function startPaymentChat(recipientAc) {
  selectedRecipient = recipientAc;
  document.getElementById('chat-recipient-ac').textContent = `A/C: ${recipientAc}`;
  
  if (recipientAc === '112233445566') {
    document.getElementById('chat-recipient-name').textContent = "Sample Number";
  } else {
    document.getElementById('chat-recipient-name').textContent = "User (" + recipientAc + ")";
  }

  // Pre-fill USD currency
  const defaultUSD = COUNTRIES_DATABASE.find(c => c.code === 'USD') || COUNTRIES_DATABASE[0];
  updateActiveCurrency(defaultUSD);

  document.getElementById('input-payment-amount').value = '';
  document.getElementById('btn-chat-pay').disabled = true;
  document.getElementById('chat-amount-bubble').style.display = 'none';

  showScreen('screen-chat');
}

function updateActiveCurrency(countryObj) {
  selectedCountry = countryObj;
  document.getElementById('selected-flag-display').textContent = countryObj.flag;
  document.getElementById('selected-currency-symbol-display').textContent = `(${countryObj.symbol})`;
  document.getElementById('selected-country-name-display').textContent = countryObj.name;
}

// ========================== COUNTRY SEARCH SELECTOR ==========================
function setupCountrySearch() {
  const searchInput = document.getElementById('input-country-search');
  const btnClose = document.getElementById('btn-close-currency-modal');

  searchInput.addEventListener('input', () => {
    const query = searchInput.value.toLowerCase().trim();
    const filtered = COUNTRIES_DATABASE.filter(c => 
      c.name.toLowerCase().includes(query) || 
      c.code.toLowerCase().includes(query)
    );
    renderCountriesList(filtered);
  });

  btnClose.addEventListener('click', () => {
    document.getElementById('modal-currency-selector').style.display = 'none';
  });
}

function renderCountriesList(list) {
  const container = document.getElementById('countries-list-container');
  container.innerHTML = '';

  if (list.length === 0) {
    container.innerHTML = '<div class="text-center font-sm text-muted padding-20">No matching currencies.</div>';
    return;
  }

  list.forEach(country => {
    const btn = document.createElement('button');
    btn.className = 'country-select-item';
    btn.innerHTML = `
      <span class="item-flag">${country.flag}</span>
      <span class="item-name">${country.name} (${country.code})</span>
      <span class="item-currency">${country.symbol}</span>
    `;

    btn.addEventListener('click', () => {
      updateActiveCurrency(country);
      document.getElementById('modal-currency-selector').style.display = 'none';
    });

    container.appendChild(btn);
  });
}

// ========================== CONVERSION SCREEN ==========================
function openConversionScreen(amountVal) {
  const isSame = (currentAccount.currency === selectedCountry.code);
  
  // Left side
  document.getElementById('conv-src-flag').textContent = currentAccount.flag || "🇮🇳";
  document.getElementById('conv-src-country').textContent = currentAccount.owner === "Sample Number" ? "United States" : "India";
  const srcSymbol = getCurrencySymbol(currentAccount.currency);
  document.getElementById('conv-src-amount').textContent = `${srcSymbol}${amountVal.toFixed(2)}`;

  // Right side
  document.getElementById('conv-dest-flag').textContent = selectedCountry.flag;
  document.getElementById('conv-dest-country').textContent = selectedCountry.name;
  document.getElementById('conv-dest-currency-symbol').textContent = `${selectedCountry.code} (${selectedCountry.symbol})`;
  
  const rate = selectedCountry.rate;
  const converted = amountVal * rate;
  document.getElementById('conv-dest-amount').textContent = `${selectedCountry.symbol}${converted.toFixed(2)}`;

  // Rate details box toggle
  const rateBox = document.getElementById('exchange-rate-details-box');
  if (isSame) {
    rateBox.style.display = 'none';
  } else {
    rateBox.style.display = 'block';
    document.getElementById('txt-live-rate-ratio').textContent = `1 ${currentAccount.currency} = ${rate} ${selectedCountry.code}`;
    const spreadVal = (1.0 + Math.random() * 0.4).toFixed(2);
    document.getElementById('txt-rate-spread').textContent = `-${spreadVal}% (Optimal Liquidity)`;
  }

  // Reset PIN
  const pinField = document.getElementById('input-payment-pin');
  const btnConfirm = document.getElementById('btn-confirm-payment');
  pinField.value = '';
  btnConfirm.disabled = true;

  showScreen('screen-conversion');
}

function setupConversionHandlers() {
  const pinField = document.getElementById('input-payment-pin');
  const btnConfirm = document.getElementById('btn-confirm-payment');

  document.getElementById('btn-back-to-chat').onclick = () => {
    showScreen('screen-chat');
  };

  pinField.addEventListener('input', () => {
    btnConfirm.disabled = (pinField.value !== '123455678');
  });

  btnConfirm.addEventListener('click', () => {
    executeLedgerPayment();
  });
}

// ========================== LEDGER TRANSACTION BLOCK ==========================
async function executeLedgerPayment() {
  showScreen('screen-loading-success');
  
  document.getElementById('payment-loader-view').style.display = 'flex';
  document.getElementById('payment-success-view').style.display = 'none';

  const amountVal = parseFloat(document.getElementById('input-payment-amount').value);
  const pinVal = document.getElementById('input-payment-pin').value;

  try {
    const data = await requestAPI(`${API_BASE}/pay`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fromAccount: currentAccount.accountNumber,
        toAccount: selectedRecipient,
        amount: amountVal,
        targetCurrency: selectedCountry.code,
        rate: selectedCountry.rate,
        password: pinVal
      })
    });

    // EVM simulation block delay (1.8s)
    setTimeout(() => {
      if (data.success) {
        displayPaymentReceipt(data.receipt, data.blockchain);
      } else {
        alert("Transaction Aborted: " + data.error);
        showScreen('screen-dashboard');
      }
    }, 1800);
  } catch (err) {
    alert("Ledger pipeline aborted: " + err.message);
    showScreen('screen-dashboard');
  }
}

function displayPaymentReceipt(tx, block) {
  document.getElementById('payment-loader-view').style.display = 'none';
  document.getElementById('payment-success-view').style.display = 'flex';

  const symbol = getCurrencySymbol(tx.toCurrency);
  document.getElementById('success-display-amount').textContent = `${symbol}${tx.convertedAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

  // Populate cert details
  document.getElementById('receipt-recipient').textContent = tx.recipientName;
  document.getElementById('receipt-to-account').textContent = tx.toAccount;
  document.getElementById('receipt-debit-amount').textContent = `₹${tx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

  const isSame = (currentAccount.currency === tx.toCurrency);
  const exchRow = document.getElementById('receipt-exchange-row');
  if (isSame) {
    exchRow.style.display = 'none';
  } else {
    exchRow.style.display = 'flex';
    document.getElementById('receipt-exchange-rate').textContent = `1 ${tx.fromCurrency} = ${tx.rate} ${tx.toCurrency}`;
  }

  document.getElementById('receipt-credit-amount').textContent = `${symbol}${tx.convertedAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
  document.getElementById('receipt-block-number').textContent = `#${block.blockNumber}`;
  document.getElementById('receipt-tx-hash').textContent = block.transactionHash;
  document.getElementById('receipt-timestamp').textContent = new Date(tx.timestamp).toLocaleString();

  // Speech Output trigger
  const announceText = `Payment successfully sent. Mined ${tx.convertedAmount.toFixed(2)} ${tx.toCurrency} to ${tx.recipientName}.`;
  speakConfirmation(announceText);

  document.getElementById('btn-success-done').onclick = () => {
    showScreen('screen-dashboard');
    refreshDashboard();
  };
}

function showInvoiceDetails(tx) {
  showScreen('screen-loading-success');
  document.getElementById('payment-loader-view').style.display = 'none';
  document.getElementById('payment-success-view').style.display = 'flex';

  const symbol = getCurrencySymbol(tx.toCurrency);
  document.getElementById('success-display-amount').textContent = `${symbol}${tx.convertedAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

  document.getElementById('receipt-recipient').textContent = tx.recipientName;
  document.getElementById('receipt-to-account').textContent = tx.toAccount;
  document.getElementById('receipt-debit-amount').textContent = `₹${tx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

  const isSame = (tx.fromCurrency === tx.toCurrency);
  const exchRow = document.getElementById('receipt-exchange-row');
  if (isSame) {
    exchRow.style.display = 'none';
  } else {
    exchRow.style.display = 'flex';
    document.getElementById('receipt-exchange-rate').textContent = `1 ${tx.fromCurrency} = ${tx.rate} ${tx.toCurrency}`;
  }

  document.getElementById('receipt-credit-amount').textContent = `${symbol}${tx.convertedAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
  document.getElementById('receipt-block-number').textContent = `#${tx.blockNumber || 'Mined'}`;
  document.getElementById('receipt-tx-hash').textContent = tx.txHash;
  document.getElementById('receipt-timestamp').textContent = new Date(tx.timestamp).toLocaleString();

  document.getElementById('btn-success-done').onclick = () => {
    showScreen('screen-dashboard');
    refreshDashboard();
  };
}

// ========================== QR VOUCHER HANDLERS ==========================
function initializeMyQR() {
  renderQRMatrix("987654321098");

  const btnGen = document.getElementById('btn-qr-general');
  const btnFix = document.getElementById('btn-qr-fixed');
  const fixedConfig = document.getElementById('fixed-rate-settings');
  const timerBox = document.getElementById('qr-timer-box');
  const qrDesc = document.getElementById('qr-desc-text');

  btnGen.onclick = () => {
    btnGen.classList.add('active');
    btnFix.classList.remove('active');
    fixedConfig.style.display = 'none';
    timerBox.style.display = 'none';
    qrDesc.innerHTML = `This QR links permanently to account <span class="white-text">987654321098</span>. System validates target currency upon scan.`;
    renderQRMatrix("987654321098");
  };

  btnFix.onclick = () => {
    btnFix.classList.add('active');
    btnGen.classList.remove('active');
    fixedConfig.style.display = 'block';
    qrDesc.textContent = "Specify rate parameters above to compile temporary EVM payload QR.";
  };

  document.getElementById('btn-generate-fixed-qr').onclick = async () => {
    const amt = parseFloat(document.getElementById('input-qr-amount').value);
    const curr = document.getElementById('select-qr-currency').value;
    
    if (isNaN(amt) || amt <= 0) return alert("Enter valid numeric value");

    try {
      const expiresAt = new Date(Date.now() + 120000).toISOString();
      const data = await requestAPI(`${API_BASE}/qr/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'FIXED',
          accountNumber: currentAccount.accountNumber,
          amount: amt,
          currency: curr,
          expiresAt
        })
      });

      if (data.success) {
        renderQRMatrix(`FIXED:${data.qr.qrId}:${amt}:${curr}`);
        startQRCountdown(120);
        timerBox.style.display = 'block';
        qrDesc.innerHTML = `Scanning credits <span class="white-text">${curr} ${amt.toFixed(2)}</span> to account <span class="white-text">987654321098</span>.`;
      }
    } catch (e) {
      alert("Error creating QR Voucher: " + e.message);
    }
  };
}

function startQRCountdown(secs) {
  if (qrTimerInterval) clearInterval(qrTimerInterval);
  const textEl = document.getElementById('qr-countdown-text');

  let left = secs;
  qrTimerInterval = setInterval(() => {
    left--;
    const m = Math.floor(left / 60).toString().padStart(2, '0');
    const s = (left % 60).toString().padStart(2, '0');
    textEl.textContent = `${m}:${s}`;
    
    if (left <= 0) {
      clearInterval(qrTimerInterval);
      textEl.textContent = "EXPIRED";
      alert("Fixed QR Voucher has expired. Regenerating code.");
      showScreen('screen-dashboard');
    }
  }, 1000);
}

function renderQRMatrix(seed) {
  const grid = document.getElementById('qr-matrix-element');
  grid.innerHTML = '';
  let sum = 0;
  for (let i = 0; i < seed.length; i++) sum += seed.charCodeAt(i);

  for (let r = 0; r < 15; r++) {
    for (let c = 0; c < 15; c++) {
      const cell = document.createElement('div');
      cell.className = 'qr-dot';
      
      const topLeft = (r < 5 && c < 5);
      const topRight = (r < 5 && c >= 10);
      const bottomLeft = (r >= 10 && c < 5);

      if (topLeft || topRight || bottomLeft) {
        const border = (r === 0 || r === 4 || c === 0 || c === 4) ||
                       (r === 10 || r === 14 || c === 0 || c === 4) ||
                       (r === 0 || r === 4 || c === 10 || c === 14);
        const center = (r === 2 && c === 2) || (r === 12 && c === 2) || (r === 2 && c === 12);
        cell.classList.add(border || center ? 'black' : 'white');
      } else {
        const val = Math.sin(r * 12.9898 + c * 78.233 + sum) * 43758.5453;
        cell.classList.add((val - Math.floor(val)) > 0.48 ? 'black' : 'white');
      }
      grid.appendChild(cell);
    }
  }
}

// ========================== SCANNER SIMULATION ==========================
function setupQRHandlers() {
  const selectScan = document.getElementById('select-scan-simulation');
  const btnScan = document.getElementById('btn-execute-simulated-scan');

  selectScan.onchange = () => {
    btnScan.disabled = (selectScan.value === '');
  };

  btnScan.onclick = () => {
    const laser = document.querySelector('.scanner-laser-line');
    laser.style.animationPlayState = 'running';

    setTimeout(() => {
      const choice = selectScan.value;
      if (choice === 'GENERAL_SENDER') {
        startPaymentChat('112233445566');
      } else if (choice === 'FIXED_100_USD') {
        selectedRecipient = '112233445566';
        const usdC = COUNTRIES_DATABASE.find(c => c.code === 'USD');
        updateActiveCurrency(usdC);
        document.getElementById('input-payment-amount').value = '100';
        openConversionScreen(100);
      } else if (choice === 'FIXED_500_INR') {
        selectedRecipient = '112233445566';
        const inrC = COUNTRIES_DATABASE.find(c => c.code === 'INR');
        updateActiveCurrency(inrC);
        document.getElementById('input-payment-amount').value = '500';
        openConversionScreen(500);
      }
    }, 1000);
  };
}

// Helpers
function getCurrencySymbol(code) {
  const c = COUNTRIES_DATABASE.find(item => item.code === code);
  return c ? c.symbol : code;
}

function getCountryFlag(code) {
  const c = COUNTRIES_DATABASE.find(item => item.code === code);
  return c ? c.flag : "🏳️";
}

function setupSoundMutes() {
  document.body.addEventListener('click', () => {
    if ('speechSynthesis' in window && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }
  }, { once: true });
}
